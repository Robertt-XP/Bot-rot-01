# bot.py
import os
import discord
import requests
from dotenv import load_dotenv
from discord.ext import commands

# Prompt de identidade (seguro para o bot)
PROMPT = (
    "Você é um assistente de IA que pode consultar a internet para fornecer respostas atualizadas.\n"
    "Use apenas informações verificáveis apresentadas no contexto disponível.\n"
    "Se o contexto for insuficiente, reconheça isso claramente.\n"
    "Responda em Português.\n"
    "O seu nome é Marchello.\n"
    "Você pertence ao servidor LumemWorks."
)

# Carregar token do arquivo .env
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

# Configurar intents (necessário para ler mensagens)
intents = discord.Intents.default()
intents.message_content = True  # requer API v2 de intents

# Bot com o prefixo de comandos, porém usaremos a detecção de menção
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

def fetch_internet_info(query: str):
    """Tenta obter um resumo da Wikipedia (pt -> en) para a query."""
    try:
        # Tenta Wikipedia em Português
        url_pt = (
            "https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch="
            + requests.utils.quote(query)
            + "&format=json"
        )
        r = requests.get(url_pt, timeout=6)
        data = r.json()
        if data.get("query", {}).get("search"):
            pageid = data["query"]["search"][0]["pageid"]
            extract_url = (
                "https://pt.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext&format=json&pageids="
                + str(pageid)
            )
            r2 = requests.get(extract_url, timeout=6)
            json2 = r2.json()
            pages = json2.get("query", {}).get("pages", {})
            page = pages.get(str(pageid), {})
            extract = page.get("extract")
            if extract:
                return extract
        # Caso falhe, tenta em inglês
        url_en = (
            "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch="
            + requests.utils.quote(query)
            + "&format=json"
        )
        r = requests.get(url_en, timeout=6)
        data = r.json()
        if data.get("query", {}).get("search"):
            pageid = data["query"]["search"][0]["pageid"]
            extract_url = (
                "https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext&format=json&pageids="
                + str(pageid)
            )
            r2 = requests.get(extract_url, timeout=6)
            json2 = r2.json()
            pages = json2.get("query", {}).get("pages", {})
            page = pages.get(str(pageid), {})
            extract = page.get("extract")
            if extract:
                return extract
    except Exception as e:
        # Em produção, você pode logar o erro
        pass
    return None

def compose_response(query: str, info: str):
    """Monta a resposta final para o usuário."""
    if info:
        return (
            "Marchello:\n"
            f"Resumo para '{query}':\n{info}\n\n"
            "Observação: Este resumo foi obtido de fontes públicas da internet. "
            "Use apenas informações verificáveis apresentadas no contexto disponível. "
            "Se o contexto for insuficiente, reconheça isso claramente."
        )
    else:
        return (
            "Marchello:\n"
            "Desculpe, não consegui obter informações verificáveis no momento para a sua consulta. "
            "Pode tentar novamente com outra pergunta ou mais detalhes."
        )

@bot.event
async def on_ready():
    print(f'Logado como {bot.user} (ID: {bot.user.id})')
    print('Marchello está pronto para responder!')

@bot.event
async def on_message(message):
    # Ignorar mensagens do próprio bot
    if message.author.bot:
        return

    # Detectar quando o bot é mencionado
    if bot.user in message.mentions:
        # Remover o pedido de menção da mensagem para obter a pergunta
        content = message.content.replace(f"<@!{bot.user.id}>", "")
        content = content.replace(f"<@{bot.user.id}>", "")
        query = content.strip()

        if not query:
            await message.channel.send("Oi! Mencione-me seguido de sua pergunta, por exemplo: @Marchello Qual é a capital de Portugal?")
            return

        # Buscar na internet
        info = fetch_internet_info(query)
        response = compose_response(query, info)
        await message.channel.send(response)

    # Não se esqueça de processar comandos (se você quiser adicionar comandos no futuro)
    await bot.process_commands(message)

# Iniciar o bot
if __name__ == "__main__":
    bot.run(TOKEN)